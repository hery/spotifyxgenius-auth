
import React from 'react';

const GENIUS_AUTH_URL = 'https://api.genius.com/oauth/authorize'
const REDIRECT_URI = 'http://spotifyxgenius.now.sh/auth'
const API_CLIENT_ID = 'wJ_3irgwB7B09JpqCwF-mZD4niYiJcxEtJprT5o3RvrzLk6vlSQ4qaHJmhyXWeOY'
const API_ACCESS_TOKEN = 'ajSsvLTpjrtHzdvCBsYljO1lUNGdxqxDbaYX5l7NR8Cfw-7qbakAA0fXhL_qmIve'

const applescript = require('applescript')
;

export default class App extends React.Component {

  constructor (props) {
      super(props)
      this.state = {
        loggedIn: false,
        query: '',
        lyrics: '',
        lyricsLoading: false,
      }
  }

  componentDidMount () {
    this.refreshCurrentSong()
    setInterval(() => {
      this.refreshCurrentSong()
    }, 5000)
    return
  }

  refreshCurrentSong () {
    const script = `if application \"Spotify\" is running then tell application \"Spotify\" \
                    to get artist of current track & \" - \" & name of current track`
    applescript.execString(script, (err, rtn) => {
      if (err) { console.debug(err) }
      const query = rtn
      if (query && query != this.state.query) {
        this.setState({ query: query, lyricsLoading: true })
        this.processSong(query)
      }
    });
  }

  processSong (query) {
    this.search(query)
    .then(
      json => {
        var song = json.response.hits && json.response.hits[0] && json.response.hits[0].result
        const songApiPath = song.api_path
        return this.apiCall(songApiPath)
      },
      error => error
    )
    .then(
      json => {
        const song = json.response && json.response.song
        const songUrl = song.url
        return this.lyrics(songUrl)
      },
      error => error
    )
    .then(
      html => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        let lyrics = doc.getElementsByClassName('lyrics')
        if (lyrics) {          
          lyrics = lyrics[0]
          lyrics = lyrics.innerHTML
          // TODO: Reset lyricsLoading on error
          this.setState({ lyrics: lyrics, lyricsLoading: false })
        }
      }
    )
  }

  lyrics (pageURL) {
    console.debug(pageURL)
    return fetch(pageURL)
    .then(
      response => response.text(),
      error => error
    )
  }

  annotation (trackId) {
    const url = `https://api.genius.com/annotations/${trackId}`
    console.debug(url)
    return fetch(url, {
      headers: {
        Authorization: `Bearer ${API_ACCESS_TOKEN}`
      }
    })
    .then(
      response => response.json(),
      error => error
    )
    .then(
      json => { console.debug(json) }
    )
  }
  
  search(q) {
    let parameters = new URLSearchParams()
    parameters.append('q', q)
    parameters = parameters.toString()
    const url = `https://api.genius.com/search?${parameters}`
    console.debug(url)
    return fetch(url, {
      headers: {
        Authorization: `Bearer ${API_ACCESS_TOKEN}`
      }
    })
    .then(
      response => response.json(),
      error => error
    )
  }

  apiCall (apiPath) {
    const url = `https://api.genius.com${apiPath}`
    console.debug(url)
    return fetch(url, {
      headers: {
        Authorization: `Bearer ${API_ACCESS_TOKEN}`
      }
    })
    .then(
      response => response.json(),
      error => error
    )
  }

  authUrl () {
    let url = GENIUS_AUTH_URL
    let parameters = new URLSearchParams()
    parameters.append('client_id', API_CLIENT_ID)
    parameters.append('redirect_uri', REDIRECT_URI)
    parameters.append('scope', 'me')
    parameters.append('state', 'meow')
    parameters.append('response_type', 'code')
    parameters = parameters.toString()
    return url + '?' + parameters
  }

  render () {
    if (this.state.lyrics && !this.state.lyricsLoading) { 
      const dangerousStyle = `
      <style>
        div.lyrics {
          // background-color: lightpink;
          overflow: scroll;
          height: 900px;
        }

        a {
          color: white;
          text-decoration: none;
          pointer-events: none;
        }
      </style>
      `
      const header = this.state.query ? `<h3>` + this.state.query + `</h3>` : '🤔'
      let html = `<div class='lyrics'>`
      html += header
      html += dangerousStyle 
      html += this.state.lyrics
      html += `</div>`
      return (
        <div style={{
          padding: 40
        }}>
          <div dangerouslySetInnerHTML={{ 
            __html: html
          }}
          style={{
            overflow: 'scroll',
            fontSize: 12,
            color: 'white'
          }}/>
        </div>
    )
    }
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        height: 1000,
        }}>
        <p style={{ flex: 1 }}></p>
        <p style={{
          height: 50,
          alignSelf: 'center',
          justifySelf: 'center',
          textAlign: 'center',
          padding: 0, margin: 0,
          flex: 0,

          color:'white',
          fontSize: 75 }}>😪</p>
        <p style={{ flex: 1 }}></p>
      </div>
    )
  }
}
